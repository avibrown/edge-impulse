#ifndef ODriveArduino_h
#define ODriveArduino_h

#include "Arduino.h"
#include "ODriveEnums.h"

class ODriveArduino {
public:
    ODriveArduino(Stream& serial);

    // Commands
    void SetPosition(int motor_number, float position);
    void SetPosition(int motor_number, float position, float velocity_feedforward);
    void SetPosition(int motor_number, float position, float velocity_feedforward, float current_feedforward);
    void SetVelocity(int motor_number, float velocity);
    void SetVelocity(int motor_number, float velocity, float current_feedforward);
    void SetCurrent(int motor_number, float current);
    void TrapezoidalMove(int motor_number, float position);

    // Getters
    float GetVelocity(int motor_number);
    float GetPosition(int motor_number);
    float GetADCVoltage(unsigned int gpio);
    float GetVbusVoltage();
    float GetIqSetpoint(unsigned int motor_number);
    float GetIqMeasured(unsigned int motor_number);
    float GetTorque(unsigned int motor_number, unsigned int motor_kv);
    float GetIbus();
    float GetMechanicalPower(unsigned int motor_number);
    float GetElectricalPower(unsigned int motor_number);
    // System commands
    bool SaveConfiguration();
    void EraseConfiguration();
    void Reboot();
    void ClearErrors();
//  ~ void EnterDFUMode();
    int GetInterruptStatus(int irqn);
    int GetDMAStatus(int stream_num);
//  ~ GetGPIOStates();
    int GetDRVFault();
//  ~ void Error();
    float GetIbusReportFilter();
    bool SetIbusReportFilter(float gain);
//    uint64_t GetSerialNumber();
    String GetFullHardwareVersion();
    String GetFullFirmwareVersion();
    bool BrakeResistorArmed();
    bool BrakeResistorSaturated();
    float GetBrakeResistorCurrent();
    uint32_t GetNSamplingEvents();
    uint32_t GetNControlLoopEvents();
    bool TaskTimersArmed();
//    ODriveArduino::TaskTimes();
//    ODriveArduino::SystemStats();
//    ODriveArduino::UserConfigLoaded();
    bool Misconfigured();
    bool OTPValid();
    uint32_t Uptime();
    uint32_t MinHeapSpace();
    uint32_t MaxStackUsageAxis();
    uint32_t MaxStackUsageUSB();
    uint32_t MaxStackUsageUART();
    uint32_t MaxStackUsageCAN();
    uint32_t MaxStackUsageStartup();
    uint32_t MaxStackUsageAnalog();
    uint32_t StackSizeAxis();
    uint32_t StackSizeUSB();
    uint32_t StackSizeUART();
    uint32_t StackSizeStartup();
    uint32_t StackSizeCAN();
    uint32_t StackSizeAnalog();
    int PriorityAxis();
    int PriorityUSB();
    int PriorityUART();
    int PriorityCAN();
    int PriorityStartup();
    int PriorityAnalog();
    void SetEnableUART_A(bool enable);
    void SetEnableUART_B(bool enable);
    bool UARTEnabled_A();
    bool UARTEnabled_B();
    void SetBaudrateUART_A(uint32_t baudrate);
    void SetBaudrateUART_B(uint32_t baudrate);
    uint32_t BaudrateUART_A();
    uint32_t BaudrateUART_B();
    bool CANEnabled_A();
    void SetEnableCAN_A(bool enable);
    // Fix name formatting
    bool I2CEnabled_A();
    void I2CEnable_A(bool enable);
    void SetMaxRegenCurrent(float current);
    float GetMaxRegenCurrent();
    void SetBrakeResistance(float resistance);
    float GetBrakeResistance();
    void EnableBreakResistor(bool enable);
    bool BrakeResistorEnabled();
    void SetDCBusUndervoltageTripLevel(float voltage);
    float GetDCBusUndervoltageTripLevel();
    void SetDCBusOvervoltageTripLevel(float voltage);
    float GetDCBusOvervoltageTripLevel();
    bool DCBusOvervoltageRampEnabled();
    void EnableDCBusOvervoltageRamp(bool enable);
    void SetDCBusOvervoltageRampStart(float voltage);
    float GetDCBusOvervoltageRampStart();
    void SetDCBusOvervoltageRampEnd(float voltage);
    float GetDCBusOvervoltageRampEnd();
    void SetDCMaxPositiveCurrent(float current);
    float GetDCMaxPositiveCurrent();
    void SetDCMaxNegativeCurrent(float current);
    float GetDCMaxNegativeCurrent();
    uint32_t ErrorGPIOPin();
    void WatchdogFeed(unsigned int axis);
    bool StepDirActive(unsigned int axis);
    uint32_t GetLastDrvFault(unsigned int axis);
    bool IsHomed(unsigned int axis);
    float GetLastErrorTime(unsigned int axis);    
    bool IsArmed(unsigned int axis);    
    bool IsCalibrated(unsigned int axis);    
    float CurrentMeasPh_A(unsigned int axis);
    float CurrentMeasPh_B(unsigned int axis);
    float CurrentMeasPh_C(unsigned int axis);
    float DCCalibPh_A(unsigned int axis);
    float DCCalibPh_B(unsigned int axis);
    float DCCalibPh_C(unsigned int axis);
    float IBus(unsigned int axis);
    float GetPhaseCurrentReverseGain(unsigned int axis);     
    float GetEffectiveCurrentLim(unsigned int axis);
    float GetMaxAllowedCurrent(unsigned int axis);     
    float GetMaxDCCalib(unsigned int axis);     
    uint32_t GetNCurrentMeasEvents(unsigned int axis);     
    uint32_t GetNPWMUpdateEvents(unsigned int axis);     
    float GetRotorFlux(unsigned int axis);     
    float GetSlipVel(unsigned int axis);     
    float GetPhaseOffset(unsigned int axis);     
    float GetStatorPhaseVel(unsigned int axis);     
    float GetStatorPhase(unsigned int axis);     
    float GetInputVel(unsigned int motor_number);
    float GetSensorlessVelocityEstimate(unsigned int motor_number);
//

    // General params
    float readFloat();
    int32_t readInt();
//    uint64_t readLong();

    // State helper
    bool run_state(int axis, int requested_state, bool wait_for_idle, float timeout = 10.0f);
private:
    String readString();

    Stream& serial_;
};

#endif //ODriveArduino_h
