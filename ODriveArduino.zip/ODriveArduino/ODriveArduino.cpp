
#include "Arduino.h"
#include "ODriveArduino.h"

// Print with stream operator
template<class T> inline Print& operator <<(Print &obj,     T arg) { obj.print(arg);    return obj; }
template<>        inline Print& operator <<(Print &obj, float arg) { obj.print(arg, 4); return obj; }

ODriveArduino::ODriveArduino(Stream& serial)
    : serial_(serial) {}

void ODriveArduino::SetPosition(int motor_number, float position) {
    SetPosition(motor_number, position, 0.0f, 0.0f);
}

void ODriveArduino::SetPosition(int motor_number, float position, float velocity_feedforward) {
    SetPosition(motor_number, position, velocity_feedforward, 0.0f);
}

void ODriveArduino::SetPosition(int motor_number, float position, float velocity_feedforward, float current_feedforward) {
    serial_ << "p " << motor_number  << " " << position << " " << velocity_feedforward << " " << current_feedforward << "\n";
}

void ODriveArduino::SetVelocity(int motor_number, float velocity) {
    SetVelocity(motor_number, velocity, 0.0f);
}

void ODriveArduino::SetVelocity(int motor_number, float velocity, float current_feedforward) {
    serial_ << "v " << motor_number  << " " << velocity << " " << current_feedforward << "\n";
}

void ODriveArduino::SetCurrent(int motor_number, float current) {
    serial_ << "c " << motor_number << " " << current << "\n";
}

void ODriveArduino::TrapezoidalMove(int motor_number, float position) {
    serial_ << "t " << motor_number << " " << position << "\n";
}

float ODriveArduino::readFloat() {
  String dataIn = readString();
      char buf[dataIn.length()];
      dataIn.toCharArray(buf, dataIn.length() + 1);
      return atof(buf);
}

//uint64_t ODriveArduino::readLong() {
//      String dataIn = readString();
//      // char buf[dataIn.length()];
//      // dataIn.toCharArray(buf, dataIn.length() + 1);
//        uint64_t val = 0;
//        uint64_t place = 1;
//        for (int i = 0; i <= dataIn.length(); i++)
//        {
//          val = val * 16;
//          val = val +(dataIn[dataIn.length() - i] - '0');
//          place = place * 10;
//        }
//        return dataIn.length();
//}


float ODriveArduino::GetVelocity(int motor_number) {
  serial_<< "r axis" << motor_number << ".encoder.vel_estimate\n";
  return ODriveArduino::readFloat();
}

float ODriveArduino::GetPosition(int motor_number) {
    serial_ << "r axis" << motor_number << ".encoder.pos_estimate\n";
    return ODriveArduino::readFloat();
}

int32_t ODriveArduino::readInt() {
    return readString().toInt();
}

bool ODriveArduino::run_state(int axis, int requested_state, bool wait_for_idle, float timeout) {
    int timeout_ctr = (int)(timeout * 10.0f);
    serial_ << "w axis" << axis << ".requested_state " << requested_state << '\n';
    if (wait_for_idle) {
        do {
            delay(100);
            serial_ << "r axis" << axis << ".current_state\n";
        } while (readInt() != AXIS_STATE_IDLE && --timeout_ctr > 0);
    }

    return timeout_ctr > 0;
}

String ODriveArduino::readString() {
    String str = "";
    static const unsigned long timeout = 1000;
    unsigned long timeout_start = millis();
    for (;;) {
        while (!serial_.available()) {
            if (millis() - timeout_start >= timeout) {
                return str;
            }
        }
        char c = serial_.read();
        if (c == '\n')
            break;
        str += c;
    }
    return str;
}

// --------------

float ODriveArduino::GetADCVoltage(unsigned int gpio) {
    serial_ << "r get_adc_voltage(" << gpio << ")\n";
    return ODriveArduino::readFloat();
}


// May need to implement "read bool" depending on the response to this
bool ODriveArduino::SaveConfiguration() {
    serial_ << "ss\n";
    return ODriveArduino::readString();
}

// May need to implement "read bool" depending on the response to this
void ODriveArduino::EraseConfiguration() {
    serial_ << "se\n";
}

void ODriveArduino::Reboot() {
    serial_ << "sr\n";
}

void ODriveArduino::ClearErrors() {
    serial_ << "sc\n";
}

//void ODriveArduino::EnterDFUMode() {
//    serial_ << "\n";
//}

int ODriveArduino::GetInterruptStatus(int irqn) {
    serial_ << "r get_interrupt_status(" << irqn << ")\n";
    return ODriveArduino::readInt();
}

int ODriveArduino::GetDMAStatus(int stream_num) {
    serial_ << "r get_dma_status(" << stream_num << ")\n";
    return ODriveArduino::readInt();
}

//void ODriveArduino::GetGPIOStates() {
//    serial_ << "\n";
//}

//void ODriveArduino::Error() {
//    serial_ << "\n";
//}

int ODriveArduino::GetDRVFault() {
    serial_ << "r get_drv_fault()\n";
    return ODriveArduino::readInt();
}

float ODriveArduino::GetIbusReportFilter() {
    serial_ << "r ibus_report_filter_k\n";
    return ODriveArduino::readFloat();
}

bool ODriveArduino::SetIbusReportFilter(float gain) {
    serial_ << "w ibus_report_filter_k " << gain << "\n";
    return (ODriveArduino::GetIbusReportFilter() == gain);
}

//uint64_t ODriveArduino::GetSerialNumber() {
//    serial_ << "r serial_number\n";
//    return ODriveArduino::readLong();
//}

String ODriveArduino::GetFullHardwareVersion() {
    serial_ << "r hw_version_major\n";
    String major = ODriveArduino::readString(); 
    serial_ << "r hw_version_minor\n";
    String minor = ODriveArduino::readString(); 
    serial_ << "r hw_version_variant\n";
    String variant = ODriveArduino::readString(); 
    return (major + "." + minor + " " + variant + "V");
}

String ODriveArduino::GetFullFirmwareVersion() {
    serial_ << "r fw_version_major\n";
    String major = ODriveArduino::readString(); 
    serial_ << "r fw_version_minor\n";
    String minor = ODriveArduino::readString(); 
    serial_ << "r fw_version_revision\n";
    String revision = ODriveArduino::readString();
    serial_ << "r fw_version_unreleased\n";
    String unofficial = ODriveArduino::readString();
    if (unofficial.toInt() == 1) {unofficial = "Unofficial release: ";} else {unofficial = "Official release: ";};
    return (unofficial + major + "." + minor + "." + revision);
}

bool ODriveArduino::BrakeResistorArmed() {
    serial_ << "r brake_resistor_armed\n";
    return ODriveArduino::readString().toInt();
}

bool ODriveArduino::BrakeResistorSaturated() {
    serial_ << "r brake_resistor_saturated\n";
    return ODriveArduino::readString().toInt();
}

float ODriveArduino::GetBrakeResistorCurrent() {
    serial_ << "r brake_resistor_current\n";
    return ODriveArduino::readString().toFloat();
}

// Need to add modulo?
uint32_t ODriveArduino::GetNSamplingEvents() {
    serial_ << "r n_evt_sampling\n";
    return ODriveArduino::readString().toInt();
}

// Need to add modulo?
uint32_t ODriveArduino::GetNControlLoopEvents() {
    serial_ << "r n_evt_control_loop\n";
    return ODriveArduino::readString().toInt();
}

bool ODriveArduino::TaskTimersArmed() {
    serial_ << "r task_timers_armed\n";
    return ODriveArduino::readString().toInt();
}

// ODriveArduino::TaskTimes() {}

// ODriveArduino::SystemStats() {}

//    ODriveArduino::UserConfigLoaded() {}

bool ODriveArduino::Misconfigured() {
    serial_ << "r misconfigured\n";
    return ODriveArduino::readString().toInt();
}

bool ODriveArduino::OTPValid() {
    serial_ << "r otp_valid\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::Uptime() {
    serial_ << "r system_stats.uptime\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::MinHeapSpace() {
    serial_ << "r system_stats.min_heap_space\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::MaxStackUsageAxis() {
    serial_ << "r system_stats.max_stack_usage_axis\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::MaxStackUsageUSB() {
    serial_ << "r system_stats.max_stack_usage_usb\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::MaxStackUsageUART() {
    serial_ << "r system_stats.max_stack_usage_uart\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::MaxStackUsageCAN() {
    serial_ << "r system_stats.max_stack_usage_can\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::MaxStackUsageStartup() {
    serial_ << "r system_stats.max_stack_usage_startup\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::MaxStackUsageAnalog() {
    serial_ << "r system_stats.max_stack_usage_analog\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::StackSizeAxis() {
    serial_ << "r system_stats.stack_size_axis\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::StackSizeUSB() {
    serial_ << "r system_stats.stack_size_usb\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::StackSizeUART() {
    serial_ << "r system_stats.stack_size_uart\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::StackSizeStartup() {
    serial_ << "r system_stats.stack_size_startup\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::StackSizeCAN() {
    serial_ << "r system_stats.stack_size_can\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::StackSizeAnalog() {
    serial_ << "r system_stats.stack_size_analog\n";
    return ODriveArduino::readString().toInt();
}

int ODriveArduino::PriorityAxis() {
    serial_ << "r system_stats.prio_axis\n";
    return ODriveArduino::readString().toInt();
}

int ODriveArduino::PriorityUSB() {
    serial_ << "r system_stats.prio_usb\n";
    return ODriveArduino::readString().toInt();
}

int ODriveArduino::PriorityUART() {
    serial_ << "r system_stats.prio_uart\n";
    return ODriveArduino::readString().toInt();
}

int ODriveArduino::PriorityCAN() {
    serial_ << "r system_stats.prio_can\n";
    return ODriveArduino::readString().toInt();
}

int ODriveArduino::PriorityStartup() {
    serial_ << "r system_stats.prio_startup\n";
    return ODriveArduino::readString().toInt();
}

int ODriveArduino::PriorityAnalog() {
    serial_ << "r system_stats.prio_analog\n";
    return ODriveArduino::readString().toInt();
}

void ODriveArduino::SetEnableUART_A(bool enable) {
    serial_ << "w config.enable_uart_a " << enable << "\n";
}

void ODriveArduino::SetEnableUART_B(bool enable) {
    serial_ << "w config.enable_uart_b " << enable << "\n";
}

bool ODriveArduino::UARTEnabled_A() {
    serial_ << "r config.enable_uart_a\n";
    return ODriveArduino::readString().toInt();
}

bool ODriveArduino::UARTEnabled_B() {
    serial_ << "r config.enable_uart_b\n";
    return ODriveArduino::readString().toInt();
}

void ODriveArduino::SetBaudrateUART_A(uint32_t baudrate) {
    serial_ << "w config.uart_a_baudrate " << baudrate << "\n";
}

void ODriveArduino::SetBaudrateUART_B(uint32_t baudrate) {
    serial_ << "w config.uart_b_baudrate " << baudrate << "\n";
}

uint32_t ODriveArduino::BaudrateUART_A() {
    serial_ << "r config.uart_a_baudrate\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::BaudrateUART_B() {
    serial_ << "r config.uart_b_baudrate\n";
    return ODriveArduino::readString().toInt();
}

bool ODriveArduino::CANEnabled_A() {
    serial_ << "r config.enable_can_a\n";
    return ODriveArduino::readString().toInt();
}

void ODriveArduino::SetEnableCAN_A(bool enable) {
    serial_ << "w config.enable_can_a " << enable << "\n";
}

bool ODriveArduino::I2CEnabled_A() {
    serial_ << "r config.enable_i2c_a\n";
    return ODriveArduino::readString().toInt();
}

void ODriveArduino::I2CEnable_A(bool enable) {
    serial_ << "w config.enable_i2c_a " << enable << "\n";
}

void ODriveArduino::SetMaxRegenCurrent(float current) {
    serial_ << "w config.max_regen_current " << current << "\n";
}

float ODriveArduino::GetMaxRegenCurrent() {
    serial_ << "r config.max_regen_current\n";
    return ODriveArduino::readString().toFloat();
}

void ODriveArduino::SetBrakeResistance(float resistance) {
    serial_ << "w config.brake_resistance " << resistance << "\n";
}

float ODriveArduino::GetBrakeResistance() {
    serial_ << "r config.brake_resistance\n";
    return ODriveArduino::readString().toFloat();
}

void ODriveArduino::EnableBreakResistor(bool enable) {
    serial_ << "w config.enable_break_resistor " << enable << "\n";
}

bool ODriveArduino::BrakeResistorEnabled() {
    serial_ << "r config.enable_brake_resistor\n";
    return ODriveArduino::readString().toInt();
}

void ODriveArduino::SetDCBusUndervoltageTripLevel(float voltage) {
    serial_ << "w config.dc_bus_undervoltage_trip_level " << voltage << "\n";
}

float ODriveArduino::GetDCBusUndervoltageTripLevel() {
    serial_ << "r config.dc_bus_undervoltage_trip_level\n";
    return ODriveArduino::readString().toFloat();
}

void ODriveArduino::SetDCBusOvervoltageTripLevel(float voltage) {
    serial_ << "w config.dc_bus_overvoltage_trip_level " << voltage << "\n";
}

float ODriveArduino::GetDCBusOvervoltageTripLevel() {
    serial_ << "r config.dc_bus_overvoltage_trip_level\n";
    return ODriveArduino::readString().toFloat();
}

bool ODriveArduino::DCBusOvervoltageRampEnabled() {
    serial_ << "r config.enable_dc_bus_overvoltage_ramp\n";
    return ODriveArduino::readString().toInt();
}

void ODriveArduino::EnableDCBusOvervoltageRamp(bool enable) {
    serial_ << "w config.enable_dc_bus_overvoltage_ramp " << enable << "\n";
}

void ODriveArduino::SetDCBusOvervoltageRampStart(float voltage) {
    serial_ << "w config.dc_bus_overvoltage_ramp_start " << voltage << "\n";
}

float ODriveArduino::GetDCBusOvervoltageRampStart() {
    serial_ << "r config.dc_bus_overvoltage_ramp_start\n";
    return ODriveArduino::readString().toFloat();
}

void ODriveArduino::SetDCBusOvervoltageRampEnd(float voltage) {
    serial_ << "w config.dc_bus_overvoltage_ramp_end " << voltage << "\n";
}

float ODriveArduino::GetDCBusOvervoltageRampEnd() {
    serial_ << "r config.dc_bus_overvoltage_ramp_end\n";
    return ODriveArduino::readString().toFloat();
}

void ODriveArduino::SetDCMaxPositiveCurrent(float current) {
    serial_ << "w config.dc_max_positive_current " << current << "\n";
}

float ODriveArduino::GetDCMaxPositiveCurrent() {
    serial_ << "r config.dc_max_positive_current\n";
    return ODriveArduino::readString().toFloat();
}

void ODriveArduino::SetDCMaxNegativeCurrent(float current) {
    serial_ << "w config.dc_max_negative_current " << current << "\n";
}

float ODriveArduino::GetDCMaxNegativeCurrent() {
    serial_ << "r config.dc_max_negative_current\n";
    return ODriveArduino::readString().toFloat();
}

uint32_t ODriveArduino::ErrorGPIOPin() {
    serial_ << "r config.error_gpio_pin\n";
    return ODriveArduino::readString().toFloat();
}

void ODriveArduino::WatchdogFeed(unsigned int axis) {
    serial_ << "w axis" << axis << ".watchdog_feed()\n";
}

bool ODriveArduino::StepDirActive(unsigned int axis) {
    serial_ << "r axis" << axis << ".step_dir_active\n";
    return ODriveArduino::readString().toInt();
}

uint32_t ODriveArduino::GetLastDrvFault(unsigned int axis) {
    serial_ << "r axis" << axis << ".last_drv_fault\n";
    return ODriveArduino::readString().toInt();
}

// Steps!!

// Current state

// Requested state

bool ODriveArduino::IsHomed(unsigned int axis) {
    serial_ << "r axis" << axis << ".is_homed\n";
    return ODriveArduino::readString().toInt();
}

float ODriveArduino::GetLastErrorTime(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.last_error_time\n";
    return ODriveArduino::readString().toFloat();    
}

bool ODriveArduino::IsArmed(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.is_armed\n";
    return ODriveArduino::readString().toInt();    
}

bool ODriveArduino::IsCalibrated(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.is_calibrated\n";
    return ODriveArduino::readString().toInt();    
}

float ODriveArduino::CurrentMeasPh_A(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.current_meas_phA\n";
    return ODriveArduino::readString().toFloat();    
}

float ODriveArduino::CurrentMeasPh_B(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.current_meas_phB\n";
    return ODriveArduino::readString().toFloat();    
}

float ODriveArduino::CurrentMeasPh_C(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.current_meas_phC\n";
    return ODriveArduino::readString().toFloat();    
}

float ODriveArduino::DCCalibPh_A(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.DC_calib_phA\n";
    return ODriveArduino::readString().toFloat();    
}

float ODriveArduino::DCCalibPh_B(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.DC_calib_phB\n";
    return ODriveArduino::readString().toFloat();    
}

float ODriveArduino::DCCalibPh_C(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.DC_calib_phC\n";
    return ODriveArduino::readString().toFloat();    
}

float ODriveArduino::IBus(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.I_bus\n";
    return ODriveArduino::readString().toFloat();    
}

float ODriveArduino::GetPhaseCurrentReverseGain(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.phase_current_reverse_gain\n";
    return ODriveArduino::readString().toFloat();     
}

float ODriveArduino::GetEffectiveCurrentLim(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.effective_current_lim\n";
    return ODriveArduino::readString().toFloat();     
}

float ODriveArduino::GetMaxAllowedCurrent(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.max_allowed_current\n";
    return ODriveArduino::readString().toFloat();     
}

float ODriveArduino::GetMaxDCCalib(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.max_dc_calib\n";
    return ODriveArduino::readString().toFloat();     
}

// Modolu?
uint32_t ODriveArduino::GetNCurrentMeasEvents(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.n_evt_current_measurement\n";
    return ODriveArduino::readString().toFloat();     
}

// Modolu
uint32_t ODriveArduino::GetNPWMUpdateEvents(unsigned int axis) {
    serial_ << "r axis" << axis << ".motor.n_evt_pwm_update\n";
    return ODriveArduino::readString().toInt();     
}

float ODriveArduino::GetRotorFlux(unsigned int axis) {
    serial_ << "r axis" << axis << ".acim_estimator.rotor_flux\n";
    return ODriveArduino::readString().toFloat();     
}

float ODriveArduino::GetSlipVel(unsigned int axis) {
    serial_ << "r axis" << axis << ".acim_estimator.slip_vel\n";
    return ODriveArduino::readString().toFloat();     
}

float ODriveArduino::GetPhaseOffset(unsigned int axis) {
    serial_ << "r axis" << axis << ".acim_estimator.phase_offset\n";
    return ODriveArduino::readString().toFloat();     
}

float ODriveArduino::GetStatorPhaseVel(unsigned int axis) {
    serial_ << "r axis" << axis << ".acim_estimator.stator_phase_vel\n";
    return ODriveArduino::readString().toFloat();     
}

float ODriveArduino::GetStatorPhase(unsigned int axis) {
    serial_ << "r axis" << axis << ".acim_estimator.stator_phase\n";
    return ODriveArduino::readString().toFloat();     
}

// //

// TESTED
float ODriveArduino::GetVbusVoltage() {
    serial_ << "r vbus_voltage\n";
    return ODriveArduino::readFloat();
}

// TESTED - TEST AGAIN WITH MOTION
float ODriveArduino::GetIqSetpoint(unsigned int motor_number) {
    serial_ << "r axis" << motor_number << ".motor.current_control.Iq_setpoint\n";
    return ODriveArduino::readFloat();
}

// TESTED - TEST AGAIN WITH MOTION
float ODriveArduino::GetIqMeasured(unsigned int motor_number) {
    serial_ << "r axis" << motor_number << ".motor.current_control.Iq_measured\n";
    return ODriveArduino::readFloat();
}

// TESTED (FIXED NAME) - TEST AGAIN WITH MOTION
float ODriveArduino::GetTorque(unsigned int motor_number, unsigned int motor_kv) {
    return (8.27 * GetIqMeasured(motor_number)) / motor_kv;
}

// TESTED - TEST AGAIN WITH MOTION
float ODriveArduino::GetIbus() {
    serial_ << "r ibus\n";
    return ODriveArduino::readFloat();
}

// TESTED - TEST AGAIN WITH MOTION
float ODriveArduino::GetMechanicalPower(unsigned int motor_number) {
    serial_ << "r axis" << motor_number << ".controller.mechanical_power\n";
    return ODriveArduino::readFloat();
}

// TESTED - TEST AGAIN WITH MOTION
float ODriveArduino::GetElectricalPower(unsigned int motor_number) {
    serial_ << "r axis" << motor_number << ".controller.electrical_power\n";
    return ODriveArduino::readFloat();
}

float ODriveArduino::GetInputVel(unsigned int motor_number) {
    serial_ << "r axis" << motor_number << ".controller.input_vel\n";
    return ODriveArduino::readFloat();
}

float ODriveArduino::GetSensorlessVelocityEstimate(unsigned int motor_number) {
    serial_ << "r axis" << motor_number << ".sensorless_estimator.vel_estimate\n";
    return ODriveArduino::readFloat();
}

// --------------
